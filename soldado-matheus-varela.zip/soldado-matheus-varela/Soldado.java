package br.edu.ifcvideiraEncapsulamento;

import java.util.Random;

public class Soldado {
	Random r = new Random();
	
	  private String nome;
	    private static int contagemSoldados = 0;
	    private static int distancia = 5;
	    private int dano =0;

	    public Soldado(String nome) {
	        this.nome = nome;
	        contagemSoldados++;
	    }

	    public void movimentar() {
	        movimentar(distancia);
	    }

	    public void movimentar(int distancia) {
	        System.out.println(this.nome + " se moveu " + distancia + " metros.");
	    }

	  
	    public void atacarF(String arma1) {
	    	arma1 =("fuzil");
	    	
	        if (contagemSoldados < 3) {
	            System.out.println(this.nome + ": ainda não, esperando o exército ficar maior.");
	        } else {
	        	this.dano = r.nextInt(80);
	            System.out.println(this.nome + " ataca com " +arma1 + ".");
	            System.out.println("e danou o inimigo com: "+this.dano);
	        }
	    }
	    public void atacarB(String arma2) {
	    	arma2 =("baioneta");
	        if (contagemSoldados < 3) {
	            System.out.println(this.nome + ": ainda não, esperando o exército ficar maior.");
	        }else {
	        	this.dano = r.nextInt(100);
	        	System.out.println(this.nome + " ataca com " +arma2 + ".");
	        	 System.out.println("e danou o inimigo com: "+this.dano);
	       }
	     
	     }
	    
	    public void atacarP(String arma3) {
	    	arma3 =("punho");
	        if (contagemSoldados < 3) {
	            System.out.println(this.nome + ": ainda não, esperando o exército ficar maior.");
	        }else {
	        	this.dano = r.nextInt(50);
	            System.out.println(this.nome + " atacou com " +arma3+ ".");
	            System.out.println("e danou o inimigo com: "+this.dano);
	       }
	     
	     }
	 
	    public static int getContagemSoldados() {
	        return contagemSoldados;
	    }
	}