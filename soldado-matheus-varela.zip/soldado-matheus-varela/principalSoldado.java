package br.edu.ifcvideiraEncapsulamento;

public class principalSoldado {
	public static void main(String[] args) {
		
		Soldado s1 = new Soldado("brigadeiro");
		Soldado s2 = new Soldado("matias");
		Soldado s3 = new Soldado("neves");
		Soldado s4 = new Soldado("cabo lozo");
		Soldado s5 = new Soldado("brigadeiro");
		Soldado s6 = new Soldado("matias");
		Soldado s7 = new Soldado("neves");
		Soldado s8 = new Soldado("cabo lozo");
		
		s1.movimentar();
		s1.atacarF("");
		s2.movimentar(20);
		s2.atacarB("");
		s3.movimentar(40);
		s3.atacarP("");

		
		System.out.println("\n");
		System.out.println("soldados: "+Soldado.getContagemSoldados());
		
	
		
	}

}
